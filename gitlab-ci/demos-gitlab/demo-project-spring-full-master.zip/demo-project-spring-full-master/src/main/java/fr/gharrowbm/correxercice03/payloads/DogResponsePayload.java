package fr.gharrowbm.correxercice03.payloads;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.NotBlank;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;
import java.util.UUID;

@Data
@Builder
public class DogResponsePayload {
    private UUID id;

    private String name;

    private String breed;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate birthDate;
}
