package fr.gharrowbm.correxercice03.exceptions;

public class ElementNotFoundException extends RuntimeException {
    public ElementNotFoundException(String elementName, Object id) {
        super(String.format("Element '%s' with id '%s' not found", elementName, id));
    }
}
