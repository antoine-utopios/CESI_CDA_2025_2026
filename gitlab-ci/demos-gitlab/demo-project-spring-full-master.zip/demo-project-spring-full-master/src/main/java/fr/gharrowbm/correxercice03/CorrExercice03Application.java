package fr.gharrowbm.correxercice03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CorrExercice03Application {

    public static void main(String[] args) {
        SpringApplication.run(CorrExercice03Application.class, args);
    }

}
