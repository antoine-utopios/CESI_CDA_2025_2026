package fr.gharrowbm.correxercice03.services;

import fr.gharrowbm.correxercice03.payloads.DogRequestPayload;
import fr.gharrowbm.correxercice03.payloads.DogResponsePayload;

import java.util.Set;
import java.util.UUID;

public interface DogService {
    DogResponsePayload findById(UUID id);
    Set<DogResponsePayload> findAll();
    UUID save(DogRequestPayload payload);
    boolean updateById(UUID dogId, DogRequestPayload payload);
    boolean deleteById(UUID dogId);
}
