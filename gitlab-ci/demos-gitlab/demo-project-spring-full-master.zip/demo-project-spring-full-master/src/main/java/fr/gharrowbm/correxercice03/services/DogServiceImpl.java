package fr.gharrowbm.correxercice03.services;

import fr.gharrowbm.correxercice03.entities.Dog;
import fr.gharrowbm.correxercice03.exceptions.ElementNotFoundException;
import fr.gharrowbm.correxercice03.mappers.DogMapper;
import fr.gharrowbm.correxercice03.payloads.DogRequestPayload;
import fr.gharrowbm.correxercice03.payloads.DogResponsePayload;
import fr.gharrowbm.correxercice03.repositories.DogRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DogServiceImpl implements DogService {
    private final DogRepository dogRepository;
    private final DogMapper dogMapper;

    @Override
    public DogResponsePayload findById(UUID dogId) {
        return dogMapper.toDogResponsePayload(dogRepository.findById(dogId).orElseThrow(() -> new ElementNotFoundException("Dog", dogId)));
    }

    @Override
    public Set<DogResponsePayload> findAll() {
        return dogRepository.findAll().stream().map(dogMapper::toDogResponsePayload).collect(Collectors.toSet());
    }

    @Override
    public UUID save(DogRequestPayload payload) {
        return dogRepository.save(dogMapper.toDog(payload)).getId();
    }

    @Override
    public boolean updateById(UUID dogId, DogRequestPayload payload) {
        Dog dog = dogRepository.findById(dogId).orElseThrow(() -> new ElementNotFoundException("Dog", dogId));

        if (payload.getName() != null)
            dog.setName(payload.getName());
        if (payload.getBreed() != null)
            dog.setBreed(payload.getBreed());
        if (payload.getBirthDate() != null)
            dog.setBirthDate(payload.getBirthDate());

        dogRepository.save(dog);

        return true;
    }

    @Override
    public boolean deleteById(UUID dogId) {
        if (!dogRepository.existsById(dogId)) throw new ElementNotFoundException("Dog", dogId);

        dogRepository.deleteById(dogId);
        return true;
    }
}
