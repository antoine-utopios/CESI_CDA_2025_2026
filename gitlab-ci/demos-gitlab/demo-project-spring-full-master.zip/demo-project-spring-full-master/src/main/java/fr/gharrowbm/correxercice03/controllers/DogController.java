package fr.gharrowbm.correxercice03.controllers;

import fr.gharrowbm.correxercice03.payloads.DogRequestPayload;
import fr.gharrowbm.correxercice03.payloads.DogResponsePayload;
import fr.gharrowbm.correxercice03.services.DogService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.Set;
import java.util.UUID;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/dogs")
public class DogController {
    private final DogService dogService;

    @GetMapping
    public ResponseEntity<Set<DogResponsePayload>> findAll() {
        return ResponseEntity.ok(dogService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<DogResponsePayload> findById(@PathVariable UUID id) {
        return ResponseEntity.ok(dogService.findById(id));
    }

    @PostMapping
    public ResponseEntity<Void> save(@RequestBody @Valid DogRequestPayload payload) {
        UUID id = dogService.save(payload);

        URI location = ServletUriComponentsBuilder
                .fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(id)
                .toUri();

        return ResponseEntity.created(location).build();
    }

    @PatchMapping("/{id}")
    public ResponseEntity<Void> update(@PathVariable UUID id, @RequestBody @Valid DogRequestPayload payload) {
        dogService.updateById(id, payload);

        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable UUID id) {
        dogService.deleteById(id);

        return ResponseEntity.noContent().build();
    }
}
