package fr.gharrowbm.correxercice03.mappers;

import fr.gharrowbm.correxercice03.entities.Dog;
import fr.gharrowbm.correxercice03.payloads.DogRequestPayload;
import fr.gharrowbm.correxercice03.payloads.DogResponsePayload;
import org.springframework.stereotype.Component;

@Component
public class DogMapper {
    public DogResponsePayload toDogResponsePayload(Dog dog) {
        return DogResponsePayload
                .builder()
                .id(dog.getId())
                .name(dog.getName())
                .breed(dog.getBreed())
                .birthDate(dog.getBirthDate())
                .build();
    }

    public Dog toDog(DogRequestPayload payload) {
        return Dog
                .builder()
                .name(payload.getName())
                .breed(payload.getBreed())
                .birthDate(payload.getBirthDate())
                .build();
    }
}
