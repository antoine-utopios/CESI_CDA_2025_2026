package fr.gharrowbm.correxercice03.controllers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import fr.gharrowbm.correxercice03.entities.Dog;
import fr.gharrowbm.correxercice03.exceptions.ElementNotFoundException;
import fr.gharrowbm.correxercice03.payloads.DogRequestPayload;
import fr.gharrowbm.correxercice03.payloads.DogResponsePayload;
import fr.gharrowbm.correxercice03.services.DogService;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.time.LocalDate;
import java.util.Set;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@WebMvcTest(DogController.class)
class DogControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private DogService dogService;

    private Set<DogResponsePayload> dogResponses;

    @BeforeEach
    void setUp() {
        dogResponses = Set.of(
                DogResponsePayload.builder().id(UUID.randomUUID()).name("Toto").breed("Labrador").birthDate(LocalDate.now().minusYears(1)).build()
        );
    }

    @Test
    @DisplayName("GET /api/v1/dogs - Get all Dogs")
    void testGetAllDogs() throws Exception {
        Mockito.when(dogService.findAll()).thenReturn(dogResponses);

        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/dogs").contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.length()").value(1))
                .andExpect(MockMvcResultMatchers.jsonPath("$[0].name").value("Toto"));
    }

    @Test
    @DisplayName("GET /api/v1/dogs/:dogId - Get Dog by Id")
    void testGetDogById() throws Exception {
        Mockito.when(dogService.findById(ArgumentMatchers.any(UUID.class))).thenReturn(dogResponses.stream().findFirst().get());

        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/dogs/" + dogResponses.stream().findFirst().get().getId())
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.name").value("Toto"));
    }

//    @Test
//    @DisplayName("GET /api/v1/dogs/:dogId - Get Dog by Id - Not Found")
//    void testGetDogByIdNotFound() throws Exception {
//        Mockito.when(dogService.findById(ArgumentMatchers.any(UUID.class))).thenThrow(new ElementNotFoundException("Dog", UUID.randomUUID()));
//
//        mockMvc.perform(MockMvcRequestBuilders.get("/api/v1/dogs/" + dogResponses.stream().findFirst().get().getId())
//                        .contentType(MediaType.APPLICATION_JSON))
//                .andExpect(MockMvcResultMatchers.status().isNotFound());
//    }

    @Test
    @DisplayName("POST /api/v1/dogs - Add new Dog")
    void testAddNewDog() throws Exception {
        DogRequestPayload requestPayload = DogRequestPayload
                .builder()
                .name("Berlioz")
                .breed("Husky")
                .birthDate(LocalDate.now().minusYears(2))
                .build();

        Mockito.when(dogService.save(ArgumentMatchers.any(DogRequestPayload.class))).thenReturn(dogResponses.stream().findFirst().get().getId());

        mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/dogs")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(requestPayload)))
                .andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(MockMvcResultMatchers.header().string("Location", Matchers.endsWith("/api/v1/dogs/" + dogResponses.stream().findFirst().get().getId())));
    }

    @Test
    @DisplayName("POST /api/v1/dogs - Add new Dog - Incorrect payload")
    void testAddNewDogIncorrectPayload() throws Exception {
        DogRequestPayload requestPayload = DogRequestPayload
                .builder()
                .build();

        mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/dogs")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(requestPayload)))
                .andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    @Test
    @DisplayName("PATCH /api/v1/dogs/:dogId - Edit a Dog with Id")
    void testEditDogById() throws Exception {
        DogRequestPayload requestPayload = DogRequestPayload
                .builder()
                .name("Berlioz edited")
                .breed("Husky")
                .birthDate(LocalDate.now().minusYears(2))
                .build();

        Mockito.when(dogService.updateById(ArgumentMatchers.any(UUID.class), ArgumentMatchers.any(DogRequestPayload.class))).thenReturn(true);

        mockMvc.perform(MockMvcRequestBuilders.patch("/api/v1/dogs/" + dogResponses.stream().findFirst().get().getId())
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(requestPayload)))
                .andExpect(MockMvcResultMatchers.status().isNoContent());
    }

    @Test
    @DisplayName("PATCH /api/v1/dogs/:dogId - Edit a Dog with Id - Invalid payload")
    void testEditDogByIdInvalidPayload() throws Exception {
        DogRequestPayload requestPayload = DogRequestPayload
                .builder()
                .build();

        mockMvc.perform(MockMvcRequestBuilders.patch("/api/v1/dogs/" + dogResponses.stream().findFirst().get().getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(requestPayload)))
                .andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    @Test
    @DisplayName("DELETE /api/v1/dogs/:dogId - Delete a Dog with Id")
    void testDeleteDogById() throws Exception {
        Mockito.when(dogService.deleteById(ArgumentMatchers.any(UUID.class))).thenReturn(true);

        mockMvc.perform(MockMvcRequestBuilders.delete("/api/v1/dogs/" + UUID.randomUUID())
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isNoContent());
    }

//    @Test
//    @DisplayName("DELETE /api/v1/dogs/:dogId - Delete a Dog with Id - Not Found")
//    void testDeleteDogByIdNotFound() throws Exception {
//        Mockito.when(dogService.deleteById(ArgumentMatchers.any(UUID.class))).thenThrow(new ElementNotFoundException("Dog", UUID.randomUUID()));
//
//        mockMvc.perform(MockMvcRequestBuilders.delete("/api/v1/dogs/" + UUID.randomUUID())
//                        .contentType(MediaType.APPLICATION_JSON))
//                .andExpect(MockMvcResultMatchers.status().isNotFound());
//    }

    private String asJsonString(Object object) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule());
            mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            return mapper.writeValueAsString(object);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}