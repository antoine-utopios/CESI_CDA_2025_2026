package fr.gharrowbm.correxercice03.repositories;

import fr.gharrowbm.correxercice03.entities.Dog;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.time.LocalDate;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
class DogRepositoryTest {
    @Autowired
    private DogRepository dogRepository;

    @Test
    @DisplayName("Save new dog")
    void testSave() {
        Dog dog = Dog
                .builder()
                .name("Toto")
                .breed("Labrador")
                .birthDate(LocalDate.now().minusYears(1))
                .build();

        Dog result = dogRepository.saveAndFlush(dog);

        assertThat(result).isNotNull();
        assertThat(result.getId()).isNotNull();
    }

    @Test
    @DisplayName("Find Dogs")
    void testFindAll() {
        Dog dog = Dog
                .builder()
                .name("Toto")
                .breed("Labrador")
                .birthDate(LocalDate.now().minusYears(1))
                .build();

        Dog dogBis = Dog
                .builder()
                .name("Medor")
                .breed("Doberman")
                .birthDate(LocalDate.now().minusYears(1))
                .build();

        dogRepository.saveAndFlush(dog);
        dogRepository.saveAndFlush(dogBis);

        List<Dog> result = dogRepository.findAll();

        assertThat(result).isNotNull();
        assertThat(result.size()).isEqualTo(2);
        assertThat(result.get(0)).isEqualTo(dog);
        assertThat(result.get(1)).isEqualTo(dogBis);
    }
}