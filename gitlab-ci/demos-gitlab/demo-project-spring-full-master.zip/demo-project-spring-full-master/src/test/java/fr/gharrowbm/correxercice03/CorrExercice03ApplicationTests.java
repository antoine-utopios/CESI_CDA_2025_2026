package fr.gharrowbm.correxercice03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CorrExercice03ApplicationTests {

    @Test
    void contextLoads() {
    }

}
