package fr.gharrowbm.correxercice03.mappers;

import fr.gharrowbm.correxercice03.entities.Dog;
import fr.gharrowbm.correxercice03.payloads.DogRequestPayload;
import fr.gharrowbm.correxercice03.payloads.DogResponsePayload;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class DogMapperTest {

    @Autowired
    DogMapper mapper;

    Dog dog;

    @BeforeEach
    void setUp() {
        dog = Dog
                .builder()
                .id(UUID.randomUUID())
                .name("Dog")
                .breed("Breed")
                .birthDate(LocalDate.now().minusYears(1))
                .build();
    }

    @Test
    @DisplayName("Dog to DogResponsePayload")
    void testToDogResponsePayload() {
        DogResponsePayload result = mapper.toDogResponsePayload(dog);

        assertThat(result).isNotNull();
        assertThat(result.getId()).isEqualTo(dog.getId());
        assertThat(result.getName()).isEqualTo(dog.getName());
        assertThat(result.getBreed()).isEqualTo(dog.getBreed());
        assertThat(result.getBirthDate()).isEqualTo(dog.getBirthDate());

    }

    @Test
    @DisplayName("DogRequestPayload to Dog")
    void testToDog() {
        DogRequestPayload request = DogRequestPayload
                .builder()
                .name(dog.getName())
                .breed(dog.getBreed())
                .birthDate(dog.getBirthDate())
                .build();

        Dog result = mapper.toDog(request);

        assertThat(result).isNotNull();
        assertThat(result.getName()).isEqualTo(dog.getName());
        assertThat(result.getBreed()).isEqualTo(dog.getBreed());
        assertThat(result.getBirthDate()).isEqualTo(dog.getBirthDate());
    }
}