package fr.gharrowbm.correxercice03.services;

import fr.gharrowbm.correxercice03.entities.Dog;
import fr.gharrowbm.correxercice03.exceptions.ElementNotFoundException;
import fr.gharrowbm.correxercice03.mappers.DogMapper;
import fr.gharrowbm.correxercice03.payloads.DogRequestPayload;
import fr.gharrowbm.correxercice03.payloads.DogResponsePayload;
import fr.gharrowbm.correxercice03.repositories.DogRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

@SpringBootTest
class DogServiceTest {
    @MockitoBean
    private DogRepository dogRepository;

    @MockitoBean
    private DogMapper dogMapper;

    @Autowired
    private DogService dogService;

    private List<Dog> dogs;
    private Set<DogResponsePayload> dogResponses;

    @BeforeEach
    void setUp() {
        UUID dogId = UUID.randomUUID();

        dogs = List.of(
                Dog.builder().id(dogId).name("Toto").breed("Labrador").birthDate(LocalDate.now().minusYears(1)).build()
        );

        dogResponses = Set.of(
                DogResponsePayload.builder().id(dogId).name("Toto").breed("Labrador").birthDate(LocalDate.now().minusYears(1)).build()
        );

        Mockito.when(dogMapper.toDogResponsePayload(ArgumentMatchers.any(Dog.class))).thenReturn(dogResponses.stream().findFirst().get());
    }

    @Test
    @DisplayName("Get all Dogs")
    void testGetAllDogs() {
        Mockito.when(dogRepository.findAll()).thenReturn(dogs);

        Set<DogResponsePayload> result = dogService.findAll();

        assertThat(result.size()).isEqualTo(1);
        assertThat(result).isEqualTo(dogResponses);
    }

    @Test
    @DisplayName("Get Dog by ID")
    void testGetDogById() {
        Mockito.when(dogRepository.findById(ArgumentMatchers.any(UUID.class))).thenReturn(Optional.of(dogs.stream().findFirst().get()));

        DogResponsePayload result = dogService.findById(UUID.randomUUID());

        assertThat(result.getId()).isEqualTo(dogs.stream().findFirst().get().getId());
        assertThat(result.getName()).isEqualTo(dogs.stream().findFirst().get().getName());
        assertThat(result.getBreed()).isEqualTo(dogs.stream().findFirst().get().getBreed());
        assertThat(result.getBirthDate()).isEqualTo(dogs.stream().findFirst().get().getBirthDate());
    }

    @Test
    @DisplayName("Get Dog by ID - Not Found")
    void testGetDogByIdNotFound() {
        Mockito.when(dogRepository.findById(ArgumentMatchers.any(UUID.class))).thenReturn(Optional.empty());

        assertThatThrownBy(() -> dogService.findById(UUID.randomUUID())).isInstanceOf(ElementNotFoundException.class);
    }

    @Test
    @DisplayName("Add new Dog")
    void testAddNewDog() {
        DogRequestPayload requestPayload = DogRequestPayload
                .builder()
                .name("Toto")
                .breed("Labrador")
                .birthDate(LocalDate.now().minusYears(1))
                .build();


        Mockito.when(dogRepository.save(ArgumentMatchers.any(Dog.class))).thenReturn(dogs.stream().findFirst().get());
        Mockito.when(dogMapper.toDog(ArgumentMatchers.any(DogRequestPayload.class))).thenReturn(dogs.stream().findFirst().get());

        UUID result = dogService.save(requestPayload);

        assertThat(result).isEqualTo(dogs.stream().findFirst().get().getId());
    }

    @Test
    @DisplayName("Update Dog by Id")
    void testUpdateDog() {
        DogRequestPayload requestPayload = DogRequestPayload
                .builder()
                .name("Toto edited")
                .breed("Labrador")
                .birthDate(LocalDate.now().minusYears(1))
                .build();

        Mockito.when(dogRepository.findById(ArgumentMatchers.any(UUID.class))).thenReturn(Optional.of(dogs.stream().findFirst().get()));
        Mockito.when(dogRepository.save(ArgumentMatchers.any(Dog.class))).thenReturn(dogs.stream().findFirst().get());

        boolean result = dogService.updateById(UUID.randomUUID(), requestPayload);

        assertThat(result).isTrue();
    }

    @Test
    @DisplayName("Update Dog by Id - Not Found")
    void testUpdateDogNotFound() {
        DogRequestPayload requestPayload = DogRequestPayload
                .builder()
                .name("Toto edited")
                .breed("Labrador")
                .birthDate(LocalDate.now().minusYears(1))
                .build();

        Mockito.when(dogRepository.findById(ArgumentMatchers.any(UUID.class))).thenReturn(Optional.empty());

        assertThatThrownBy(() -> dogService.updateById(UUID.randomUUID(), requestPayload)).isInstanceOf(ElementNotFoundException.class);
    }

    @Test
    @DisplayName("Delete Dog by ID")
    void testDeleteDogById() {
        UUID id = UUID.randomUUID();

        Mockito.when(dogRepository.existsById(ArgumentMatchers.any(UUID.class))).thenReturn(true);

        boolean result = dogService.deleteById(id);

        assertThat(result).isTrue();
    }

    @Test
    @DisplayName("Delete Dog by ID - Not Found")
    void testDeleteDogByIdNotFound() {
        UUID id = UUID.randomUUID();

        Mockito.when(dogRepository.existsById(ArgumentMatchers.any(UUID.class))).thenReturn(false);

        assertThatThrownBy(() -> dogService.deleteById(id)).isInstanceOf(ElementNotFoundException.class);
    }



}